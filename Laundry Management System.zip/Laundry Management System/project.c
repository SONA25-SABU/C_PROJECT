#include <stdio.h>
#include <string.h>

#define MAX_USERS 100
#define MAX_WORKERS 100
#define MAX_ORDERS 100
#define MAX_TASKS 100

// User structure
typedef struct
{
    char username[50];
    char password[50];
} User;

// Worker structure
typedef struct
{
    char name[50];
} Worker;

// Task structure
typedef struct
{
    char description[100];
    int status; // 0: Pending, 1: Finished
} Task;

// Order structure
typedef struct
{
    char dressType[50];
    int quantity;
    float price;
    char purpose[50];
    int status; // 0: Pending, 1: Paid
} Order;

// Function prototypes
int adminLogin();
void adminMenu(Worker workers[], int *numWorkers, Task tasks[], int *numTasks, User users[], int *numUsers);
void customerMenu(User users[], int *numUsers, Order orders[], int *numOrders, Task tasks[], int *numTasks);
void workerMenu(Worker workers[], int numWorkers, Order orders[], int numOrders, Task tasks[], int *numTasks);
void addWorker(Worker workers[], int *numWorkers);
void removeWorker(Worker workers[], int *numWorkers);
void displayTotalRevenue(Task tasks[], int numTasks);
void listTasksWithStatus(Task tasks[], int numTasks, int status);
void listUsers(User users[], int numUsers);
void listWorkers(Worker workers[], int numWorkers);
void registerCustomer(User users[], int *numUsers);
void placeOrder(Order orders[], int *numOrders);
void checkOrderStatus(Task tasks[], int numTasks);
void makePayment(float totalAmount);

int main()
{
    // Initialize admin login credentials
    User admin = {"admin", "admin123"};

    // Initialize users, workers, orders, and tasks
   User users[MAX_USERS];
    Worker workers[MAX_WORKERS];
    Order orders[MAX_ORDERS];
    Task tasks[MAX_TASKS];

    int numUsers = 0;
    int numWorkers = 0;
    int numOrders = 0;
    int numTasks = 0;

    int choice;
    do
    {
        // Display main menu
        printf("\nMenu:\n");
        printf("1. Admin\n");
        printf("2. Customer\n");
        printf("3. Worker\n");
        printf("4. Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            // Admin operations
            adminMenu(workers, &numWorkers, tasks, &numTasks, users, &numUsers);
            break;

        case 2:
            // Customer operations
            customerMenu(users, &numUsers, orders, &numOrders, tasks, &numTasks);
            break;

        case 3:
            // Worker operations
            workerMenu(workers, numWorkers, orders, numOrders, tasks, &numTasks);
            break;

        case 4:
            printf("Exiting...\n");
            break;

        default:
            printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 4);

    return 0;
}

// Function to validate admin login
int adminLogin()
{
    char username[50];
    char password[50];

    printf("Enter username (admin): ");
    scanf("%s", username);

    printf("Enter password: ");
    scanf("%s", password);

    if (strcmp(username, "admin") == 0 && strcmp(password, "admin123") == 0)
    {
        printf("Login successful!\n");
        return 1; // Login successful
    }
    else
    {
        printf("Login failed.\n");
        return 0; // Login failed
    }
}

void adminMenu(Worker workers[], int *numWorkers, Task tasks[], int *numTasks, User users[], int *numUsers)
{
     if (!adminLogin())
    {
        printf("Admin login failed. Exiting...\n");
        return;
    }

    int choice;
    do
    {
        // Display admin menu
        printf("\nAdmin Menu:\n");
        printf("1. Add Worker\n");
        printf("2. Remove Worker\n");
        printf("3. Display Total Revenue\n");
        printf("4. List Pending Tasks\n");
        printf("5. List Finished Tasks\n");
        printf("6. List Users\n");
        printf("7. List Workers\n");
        printf("8. Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            addWorker(workers, numWorkers);
            break;
        case 2:
            removeWorker(workers, numWorkers);
            break;
        case 3:
            displayTotalRevenue(tasks, *numTasks);
            break;
        case 4:
            listTasksWithStatus(tasks, *numTasks, 0); // List pending tasks
            break;
        case 5:
            listTasksWithStatus(tasks, *numTasks, 1); // List finished tasks
            break;
        case 6:
            listUsers(users, *numUsers);
            break;
        case 7:
            listWorkers(workers, *numWorkers);
            break;
        case 8:
            printf("Exiting admin menu...\n");
            break;
        default:
            printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 8);
}


                                                 
// Function to handle customer operations
void customerMenu(User users[], int *numUsers, Order orders[], int *numOrders, Task tasks[], int *numTasks)
{
    int choice;

        {
            // Display customer menu
            printf("\nCustomer Menu:\n");
            printf("1. Register\n");
            printf("2. Place Order\n");
            printf("3. Check Order Status\n");
            printf("4. Exit\n");

            printf("Enter your choice: ");
            scanf("%d", &choice);

            switch (choice)
            {
            case 1:
                registerCustomer(users, numUsers);
                break;
            case 2:
                placeOrder(orders, numOrders);
                break;
            case 3:
                checkOrderStatus(tasks, *numTasks);
                break;
            case 4:
                printf("Exiting customer menu...\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
            }
        } 
}


// Function to handle worker operations
void workerMenu(Worker workers[], int numWorkers, Order orders[], int numOrders, Task tasks[], int *numTasks)
{
    char workerName[50];
    printf("Enter your name as a worker: ");
    scanf("%s", workerName);

    int workerAuthenticated = 0;
    for (int i = 0; i < numWorkers; i++)
    {
        if (strcmp(workerName, workers[i].name) == 0)
        {
            workerAuthenticated = 1;
            break;
        }
    }

    if (!workerAuthenticated)
    {
        printf("Authentication failed. Exiting worker menu...\n");
        return;
    }

    int workerChoice;
    do
    {
        // Display worker menu
        printf("\nWorker Menu:\n");
        printf("1. Select Paid and Pending Orders\n");
        printf("2. Update Task Status\n");
        printf("3. Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &workerChoice);

        switch (workerChoice)
        {
        case 1:
            // Select paid and pending orders
            printf("Paid and Pending Orders:\n");
            for (int i = 0; i < numOrders; i++)
            {
                if (orders[i].status == 1 && tasks[i].status == 0)
                {
                    printf("%d. Dress: %s, Quantity: %d, Price: $%.2f\n", i + 1,
                           orders[i].dressType, orders[i].quantity, orders[i].price);
                }
            }
            break;

        case 2:
            // Update task status
            if (*numTasks > 0)
            {
                printf("List of Tasks:\n");
                for (int i = 0; i < *numTasks; i++)
                {
                    printf("%d. %s - %s\n", i + 1, tasks[i].description,
                           tasks[i].status ? "Finished" : "Pending");
                }

                int taskChoice;
                printf("Enter the number of the task to update: ");
                scanf("%d", &taskChoice);

                if (taskChoice > 0 && taskChoice <= *numTasks)
                {
                    printf("Update Task Status:\n");
                    printf("1. Pending\n");
                    printf("2. Finished\n");

                    int statusChoice;
                    printf("Enter the number of the status: ");
                    scanf("%d", &statusChoice);

                    if (statusChoice == 1)
                    {
                        tasks[taskChoice - 1].status = 0; // Pending
                        printf("Task marked as pending.\n");
                    }
                    else if (statusChoice == 2)
                    {
                        tasks[taskChoice - 1].status = 1; // Finished
                        printf("Task marked as finished.\n");
                    }
                    else
                    {
                        printf("Invalid status choice.\n");
                    }
                }
                else
                {
                    printf("Invalid task choice.\n");
                }
            }
            else
            {
                printf("No tasks available.\n");
            }
            break;

        case 3:
            printf("Exiting worker menu...\n");
            break;

        default:
            printf("Invalid choice. Please try again.\n");
        }
    } while (workerChoice != 3);
}

// Function to add a worker
void addWorker(Worker workers[], int *numWorkers)
{
    if (*numWorkers < MAX_WORKERS)
    {
        printf("Enter the name of the new worker: ");
        scanf("%s", workers[*numWorkers].name);
        (*numWorkers)++;
        printf("Worker added successfully.\n");
    }
    else
    {
        printf("Maximum number of workers reached.\n");
    }
}

// Function to remove a worker
void removeWorker(Worker workers[], int *numWorkers)
{
    if (*numWorkers > 0)
    {
        printf("List of Workers:\n");
        for (int i = 0; i < *numWorkers; i++)
        {
            printf("%d. %s\n", i + 1, workers[i].name);
        }

        int choice;
        printf("Enter the number of the worker to remove: ");
        scanf("%d", &choice);

        if (choice > 0 && choice <= *numWorkers)
        {
            // Remove the selected worker by shifting elements
            for (int i = choice - 1; i < *numWorkers - 1; i++)
            {
                strcpy(workers[i].name, workers[i + 1].name);
            }
            (*numWorkers)--;
            printf("Worker removed successfully.\n");
        }
        else
        {
            printf("Invalid choice.\n");
        }
    }
    else
    {
        printf("No workers to remove.\n");
    }
}

// Function to display total revenue
void displayTotalRevenue(Task tasks[], int numTasks)
{
    float totalRevenue = 0.0;

    for (int i = 0; i < numTasks; i++)
    {
        // Assuming each task has a cost associated with it
        totalRevenue += 10.0; // Replace with the actual calculation based on your pricing logic
    }

    printf("Total Revenue: $%.2f\n", totalRevenue);
}

// Function to list tasks with a specific status
void listTasksWithStatus(Task tasks[], int numTasks, int status)
{
    if (status == 0)
    {
        printf("Pending Tasks:\n");
    }
    else
    {
        printf("Finished Tasks:\n");
    }

    for (int i = 0; i < numTasks; i++)
    {
        if (tasks[i].status == status)
        {
            printf("%d. %s\n", i + 1, tasks[i].description);
        }
    }
}

// Function to list users
void listUsers(User users[], int numUsers)
{
    printf("List of Users:\n");

    for (int i = 0; i < numUsers; i++)
    {
        printf("%d. %s\n", i + 1, users[i].username);
    }
}

// Function to list workers
void listWorkers(Worker workers[], int numWorkers)
{
    printf("List of Workers:\n");

    for (int i = 0; i < numWorkers; i++)
    {
        printf("%d. %s\n", i + 1, workers[i].name);
    }
}

// Function to register a customer
void registerCustomer(User users[], int *numUsers)
{
    // Implement the logic to register a customer
    // Assume a simple registration by entering username and password
    if (*numUsers < MAX_USERS)
    {
        printf("Enter a username: ");
        scanf("%s", users[*numUsers].username);
        printf("Enter a password: ");
        scanf("%s", users[*numUsers].password);
        (*numUsers)++;
        printf("Customer registered successfully.\n");
    }
    else
    {
        printf("Maximum number of customers reached.\n");
    }
}

// Function to place an order
void placeOrder(Order orders[], int *numOrders)
{
    // Dress types and their corresponding prices
    char dressTypes[][50] = {"shirt", "pant", "jeans", "blazers", "salvar", "saree", "banyan"};
    float dressPrices[] = {5.0, 4.0, 6.0, 8.0, 7.0, 10.0, 3.0};

    // Display available dress types
    printf("Available Dress Types:\n");
    for (int i = 0; i < sizeof(dressTypes) / sizeof(dressTypes[0]); i++)
    {
        printf("%d. %s\n", i + 1, dressTypes[i]);
    }

    // Get user input for dress type
    int dressChoice;
    printf("Enter the number of the dress type: ");
    scanf("%d", &dressChoice);

    if (dressChoice >= 1 && dressChoice <= sizeof(dressTypes) / sizeof(dressTypes[0]))
    {
        strcpy(orders[*numOrders].dressType, dressTypes[dressChoice - 1]);
        printf("Enter the quantity: ");
        scanf("%d", &orders[*numOrders].quantity);

        // Display available purposes
        printf("Available Purposes:\n");
        printf("1. Wash - $2.0 per unit\n");
        printf("2. Iron - $1.5 per unit\n");
        printf("3. Dry Clean - $3.0 per unit\n");

        // Get user input for purpose
        int purposeChoice;
        printf("Enter the number of the purpose: ");
        scanf("%d", &purposeChoice);

        // Calculate the price based on purpose and quantity
        switch (purposeChoice)
        {
        case 1:
            orders[*numOrders].price = 2.0 * orders[*numOrders].quantity;
            strcpy(orders[*numOrders].purpose, "Wash");
            break;
        case 2:
            orders[*numOrders].price = 1.5 * orders[*numOrders].quantity;
            strcpy(orders[*numOrders].purpose, "Iron");
            break;
        case 3:
            orders[*numOrders].price = 3.0 * orders[*numOrders].quantity;
            strcpy(orders[*numOrders].purpose, "Dry Clean");
            break;
        default:
            printf("Invalid purpose choice.\n");
            return;
        }

        orders[*numOrders].status = 1; // Set order status to paid
        (*numOrders)++;
        printf("Order placed successfully.\n");
    }
    else
    {
        printf("Invalid dress type choice.\n");
    }
}

// Function to check the status of an order
void checkOrderStatus(Task tasks[], int numTasks)
{
    // Implement the logic to check order status
    // Assume a simple display of tasks and their status
    printf("Order Status:\n");
    for (int i = 0; i < numTasks; i++)
    {
        printf("%d. %s - %s\n", i + 1, tasks[i].description, tasks[i].status ? "Finished" : "Pending");
    }
}

// Function to make a payment
void makePayment(float totalAmount)
{
    // Implement the logic to make a payment
    // Assume a simple payment confirmation
    printf("Total Amount: $%.2f\n", totalAmount);
    printf("1. Pay\n");
    printf("2. Cancel\n");

    int choice;
    printf("Enter your choice: ");
    scanf("%d", &choice);

    if (choice == 1)
    {
        printf("Payment successful. Thank you!\n");
    }
    else
    {
        printf("Payment canceled.\n");
    }
}
